
export enum ConsortiumType {
  PROPERTY = 'Imóvel',
  VEHICLE = 'Automóvel',
  SERVICE = 'Serviços'
}

export interface SimulationState {
  type: ConsortiumType;
  amount: number;
  name: string;
  phone: string;
}

export const WHATSAPP_NUMBER = "5548991455194";
export const INSTAGRAM_HANDLE = "@volpiconsultor";
export const INSTAGRAM_URL = "https://instagram.com/volpiconsultor";
export const GITHUB_URL = "https://github.com/volpiempresas-bit/Volpi-Consultoria.git";
export const ADDRESS = "R. Dr. Heitor Blum, 309 - Estreito, Florianópolis - SC, 88075-110";
